//Pollution Map
const mapSvg = d3.select("#map-svg");
const tooltip = d3.select(".tooltip");
const projection = d3.geoAlbersUsa().translate([480, 300]).scale(1000);
const path = d3.geoPath().projection(projection);
const color = d3.scaleSequential(d3.interpolateTurbo).domain([0, 50]);

let mapData, monthOrder = [], interval, currentIndex = 0, playing = false;
const dropdown = d3.select("#month-select");
const playButton = d3.select("#play-button");
const prevButton = d3.select("#prev-button");
const nextButton = d3.select("#next-button");

d3.json("https://cdn.jsdelivr.net/npm/us-atlas@3/states-10m.json").then(us => {
  mapData = topojson.feature(us, us.objects.states).features;

  d3.csv("dataset.csv").then(data => {
    data.forEach(d => {
      d.Date = new Date(d.Date);
      d.Month_Year = d.Date.toLocaleString('default', { month: 'long' }).toLowerCase() + "_" + d.Date.getFullYear();
      d.Pollution = +d.pollution;
    });

    monthOrder = Array.from(d3.rollup(data, v => v[0].Date, d => d.Month_Year))
      .sort((a, b) => new Date(a[1]) - new Date(b[1]))
      .map(d => d[0]);

    monthOrder.forEach(d => {
      dropdown.append("option")
        .text(d.replace("_", " ").replace(/\b\w/g, c => c.toUpperCase()))
        .attr("value", d);
    });

    dropdown.on("change", function () {
      stopAnimation();
      currentIndex = monthOrder.indexOf(this.value);
      renderMap(this.value, data);
    });

    if (monthOrder.length > 0) {
      dropdown.property("value", monthOrder[0]);
      renderMap(monthOrder[0], data);
    }

    renderLegend();

    playButton.on("click", () => { playing ? stopAnimation() : startAnimation(data); });
    prevButton.on("click", () => { stopAnimation(); moveMonth(-1, data); });
    nextButton.on("click", () => { stopAnimation(); moveMonth(1, data); });
  });
});

function renderMap(monthYear, fullData) {
  const monthData = fullData.filter(d => d.Month_Year === monthYear);
  const avgPollution = d3.rollup(monthData, v => d3.mean(v, d => d.Pollution), d => d.State);

  mapSvg.selectAll("path").remove();

  mapSvg.append("g")
    .selectAll("path")
    .data(mapData)
    .join("path")
      .attr("d", path)
      .attr("fill", d => {
        const pollution = avgPollution.get(d.properties.name);
        return color(typeof pollution === "number" ? pollution : 10);
      })
      .attr("stroke", "#333")
      .on("mouseover", (event, d) => {
        const pollution = avgPollution.get(d.properties.name);
        tooltip.style("opacity", 1)
          .html(`<strong>${d.properties.name}</strong><br>Pollution: ${typeof pollution === "number" ? pollution.toFixed(2) : '10 (Default)'}`)
          .style("left", (event.pageX + 10) + "px")
          .style("top", (event.pageY - 28) + "px");
      })
      .on("mouseout", () => tooltip.style("opacity", 0));
}

function renderLegend() {
  const legend = d3.select("#legend").html("");
  legend.append("span").attr("class", "legend-label").text("Low Pollution (0)");
  legend.append("div").attr("class", "legend-gradient");
  legend.append("span").attr("class", "legend-label").text("High Pollution (50)");
}

function startAnimation(data) {
  playing = true;
  playButton.text("⏸ Pause");
  interval = setInterval(() => { moveMonth(1, data); }, 750);
}

function stopAnimation() {
  playing = false;
  clearInterval(interval);
  playButton.text("▶ Play");
}

function moveMonth(step, data) {
  currentIndex = (currentIndex + step + monthOrder.length) % monthOrder.length;
  dropdown.property("value", monthOrder[currentIndex]);
  renderMap(monthOrder[currentIndex], data);
}

// Line Chart
d3.csv("Average.csv").then(data => {
  data.forEach(d => {
    d.Year = +d.Year;
    d["O3 Mean"] = +d["O3 Mean"];
    d["CO Mean"] = +d["CO Mean"];
    d["SO2 Mean"] = +d["SO2 Mean"];
    d["NO2 Mean"] = +d["NO2 Mean"];
  });
  data = data.filter(d => d.Year >= 2013);

  const svg = d3.select("#line-chart-svg"),
        margin = { top: 30, right: 100, bottom: 50, left: 60 },
        width = +svg.attr("width") - margin.left - margin.right,
        height = +svg.attr("height") - margin.top - margin.bottom,
        g = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);

  const features = ["O3 Mean", "CO Mean", "SO2 Mean", "NO2 Mean"];
  const x = d3.scaleLinear().domain(d3.extent(data, d => d.Year)).range([0, width]);
  const y = d3.scaleLinear().domain([0, d3.max(data, d => d3.max(features, f => d[f]))]).nice().range([height, 0]);
  const color = d3.scaleOrdinal(d3.schemeSet2).domain(features);

  g.append("g")
    .attr("transform", `translate(0,${height})`)
    .call(d3.axisBottom(x).tickFormat(d3.format("d")))
    .selectAll("text").style("font-size", "12px");

  g.append("g")
    .call(d3.axisLeft(y))
    .selectAll("text").style("font-size", "12px");

  features.forEach(feature => {
    const lineData = data.map(d => ({ Year: d.Year, value: d[feature] }));

    g.append("path")
      .datum(lineData)
      .attr("fill", "none")
      .attr("stroke", color(feature))
      .attr("stroke-width", 2)
      .attr("d", d3.line()
        .x(d => x(d.Year))
        .y(d => y(d.value))
        .curve(d3.curveMonotoneX)
      );

    g.append("text")
      .datum(lineData[lineData.length - 1])
      .attr("x", d => x(d.Year) + 5)
      .attr("y", d => y(d.value))
      .attr("fill", color(feature))
      .attr("font-size", "12px")
      .attr("font-weight", "600")
      .text(feature);
  });
});

// Bar Chart
d3.csv("Average_AQI_2013_Onwards.csv").then(data => {
  data.forEach(d => {
    d.Year = +d.Year;
    d.AQI = +d["Average AQI"];
  });

  const svg = d3.select("#bar-chart-svg"),
        margin = {top: 30, right: 30, bottom: 70, left: 60},
        width = +svg.attr("width") - margin.left - margin.right,
        height = +svg.attr("height") - margin.top - margin.bottom,
        g = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);

  const x = d3.scaleBand()
      .domain(data.map(d => d.Year))
      .range([0, width])
      .padding(0.2);

  const y = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.AQI)])
      .nice()
      .range([height, 0]);

  g.append("g")
      .attr("transform", `translate(0,${height})`)
      .call(d3.axisBottom(x).tickFormat(d3.format("d")))
      .selectAll("text")
      .attr("transform", "rotate(-45)")
      .style("text-anchor", "end");

  g.append("g")
      .call(d3.axisLeft(y));

  g.selectAll(".bar")
    .data(data)
    .join("rect")
      .attr("class", "bar")
      .attr("x", d => x(d.Year))
      .attr("width", x.bandwidth())
      .attr("y", height)
      .attr("height", 0)
      .attr("fill", "#69b3a2")
    .transition()
      .duration(1000)
      .attr("y", d => y(d.AQI))
      .attr("height", d => height - y(d.AQI));
});
