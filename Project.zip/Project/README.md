# Data Visualization Project: Air Quality Trends in the United States

## Group Members
-Pambala vignesh – vpambala@umassd.edu -02147534 

-Sindhu Pathipati – spathipati@umassd.edu - 02190845




---

## How to Run the Visualization
1. **Download the Project Files**: Ensure you have the following files:
    - `index.html`
    - `style.css`
    - `script.js`
    - `dataset.csv`
    - `AQI.csv`
    - `Average.csv`
    - `Average_AQI_2013_Onwards.csv`

2. Run it on terminal :
- Open your terminal.
- Navigate to the project folder using the `cd` command:
      
  cd path/to/your/project-folder
      
- Start a simple server using Node.js (you can install http-server if you haven't):
      
   npm install -g http-server
    
- Then run:
    
   http-server
    
   http://localhost:8080
    
- Open `http://localhost:8080/index.html` in your browser.


---

## How to Read the Visualizations

### 1. **Monthly Pollution Map**
- **Axes/Encoding**:
  - The United States map is used.
  - States are color-coded using a gradient.
  - The color represents the pollution level: lighter colors indicate lower pollution, and darker colors indicate higher pollution.
- **Idiom**: *Choropleth Map*
  - Maps geographical regions using color to show differences in pollution concentration.
- **How to Interact**:
  - Select a month/year from the dropdown to view pollution data for that time.
  - Use `Prev`, `Next`, and `Play` buttons to navigate across months dynamically.
  - Hover over a state to see the average pollution value for that state in the selected month.

### 2. **Yearly Average Pollution Trends (O₃, CO, SO₂, NO₂)**
- **Axes/Encoding**:
  - **X-axis**: Year (2013 - 2023)
  - **Y-axis**: Mean concentration value of each pollutant.
  - Different lines represent different pollutants: O₃ (Ozone), CO (Carbon Monoxide), SO₂ (Sulfur Dioxide), NO₂ (Nitrogen Dioxide).
- **Idiom**: *Line Chart*
  - Line charts are used to show how pollutant levels change year-by-year.
- **How to Read**:
  - Follow each colored line to see how each pollutant's average concentration changed over time.
  - Labels next to the lines indicate the pollutant being tracked.

### 3. **Yearly Average AQI (2013 Onwards)**
- **Axes/Encoding**:
  - **X-axis**: Year (2013 - 2023)
  - **Y-axis**: Average AQI (Air Quality Index).
- **Idiom**: *Bar Chart*
  - Shows AQI values for each year as bars.
- **How to Read**:
  - Taller bars represent years with higher average AQI (worse air quality).
  - Shorter bars represent better air quality years.

---

## Screenshot of the Framework








![alt text](image-1.png)
![alt text](image.png)